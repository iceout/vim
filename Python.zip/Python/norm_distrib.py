from scipy import stats

class MDNorm(object):
    """\
    Multi dimensional normal distribution. Variables are independent from each other.
    """
    def __init__(self, dim=2, loc=0, scale=1):
        if isinstance(loc, (float, int, long)):
            loc = [loc]*dim
        if isinstance(scale, (float, int, long)):
            scale = [scale]*dim
        self.rvs = [stats.norm(loc=loc[i], scale=scale[i]) for i in range(dim)]

    def sample(self, n=1):
        return [rv.rvs(n) for rv in self.rvs]
# TODO to do 
