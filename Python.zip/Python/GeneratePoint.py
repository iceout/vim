#!/usr/bin/python

from __future__ import with_statement
import cPickle as pickle
from matplotlib import pyplot
from norm_distrib import MDNorm

colors = ['g', 'g', 'g']
scales = [4, 1.3, 1.8]
locs   = [-8, [9, -13], [1, 2.5]]
nsmp   = [500, 350, 400]
ndist  = len(locs)

norms = [MDNorm(loc=locs[i], scale=scales[i]) \
        for i in range(ndist)]
samples = [norms[i].sample(nsmp[i]) \
        for i in range(ndist)]

pyplot.hold(True)
for i in range(ndist):
    pyplot.scatter(samples[i][0], samples[i][1], c=colors[i])
pyplot.savefig('cluster.png', format='png', transparent=True)
with open('cluster.pkl', 'wb') as out:
    pickle.dump(samples, out)
