#!/usr/bin/python
# Filename: function.py

def sayHello():
    print 'Hello World!' # block belonging to the function

sayHello() # call the function 
print 5*3
print "hi" * 3
print "hi", 3 * 3
